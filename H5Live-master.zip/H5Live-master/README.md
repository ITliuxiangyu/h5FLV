# H5Live
## 只能运行在chrome和火狐浏览器上面,需要浏览器支持fetch Api
### Can play FLV  live  HTML 5 projects
### 可以直接播放flv直播的html5工程
### 基于流式下载,软编flv到mp4格式
### 这里感谢mama-hd的作者的大力帮助
#### 现在还是不太稳定,只是证明了可以播放flv直播,后续会解决稳定问题
#### [线上示例(demo)](http://gao111.top/h5live/H5LiveFlv.html) 
###### 有兴趣者可以联系我邮箱332065255@qq.com互相探讨
![screenshot](http://gao111.top/img/1.jpg)
-----------------------------------------
### 第一次更新
		* 代码没有整理
		* 后续将html里面的播放代码整理到js中
------------------------------------
### 第二次更新
		* 代码分离
		* 增加注释