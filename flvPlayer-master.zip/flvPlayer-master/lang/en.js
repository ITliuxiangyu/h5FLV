﻿CKEDITOR.plugins.setLang('flvPlayer', 'en', {
    flvPlayer: {
        flvPlayer: 'FLV Player',
        btnLabel: 'FLV Player',
        label: 'Insert/Edit video',
        title: 'Insert/Edit Video (flv, mp4)',
        notEmpty: 'Please insert the URL to the .flv or .mp4 file.',
        upload : 'Upload',
        infoTab : 'Info',
        width : 'Width',
        height : 'Height',
        border : 'Border',
        hSpace : 'HSpace',
        vSpace : 'VSpace',
        align : 'Align',
        alignLeft : 'Left',
        alignRight : 'Right',
        btnUpload : 'Upload',
        allowFullscreen : 'Allow Fullscreen',
        autoplay : 'Autoplay'
    }
});